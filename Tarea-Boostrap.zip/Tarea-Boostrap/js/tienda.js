document.addEventListener('DOMContentLoaded', async () => {

    const listaProductos = document.querySelector('#listaProductos')

    const productos = await getProductos()

    let body = ""

    for (let { image, title, price, category } of productos) {
        body += `

       <div class="card" style="width: 18rem;">
               <img 
               class="card-img-top"
               width="100"
               src="${image}" 
               alt="${title}">
               <div class="card-body">
               <h3 class="card-title"> ${title.length > 20 ? title.substring(0, 20) + "..." : title}</h3>
               <span class="card-text">${category}</span>
               <span class="card-text">L${price}</span>
   
               <button class="boton" type="button" >Mas información </button>
          </div>
          </div>
       `
    }

    listaProductos.innerHTML = body

})

const getProductos = async () => {

    const response = await fetch('https://fakestoreapi.com/products')

    const productos = await response.json()

    return productos

}
